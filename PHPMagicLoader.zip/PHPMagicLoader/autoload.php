<?php

/**
 * 
 */


class MagicLoad
{
	public $paths = array();

	
	function __construct($libraries){
	# code...
		$root_path = __DIR__;
		$libraries_set = explode('|',$libraries);
		$root_path = str_replace('\PHPMagicLoader','',$root_path);
		$directories_set = scandir($root_path);
		foreach ($directories_set as $key => $dir_name) {
			# code...
			if ($this->isFolder($dir_name)) {
				# code...
				$newPath = $root_path."\\".$dir_name;
				$this->autoload_libraries($newPath,$libraries);
			}
			foreach ($libraries_set as $key => $library) {
				# code...
				if($dir_name == $library) {
				# code...
				$path = $root_path."\\".$library;
				$path = str_replace("\\","/",$path);
				$this->paths[] = $path;
			}
			}
		}	
	}

	public function autoload_libraries($p,$libraries)
	{
		# code...
		$directories_set = scandir($p);
		$libraries_set = explode('|',$libraries);
		foreach ($directories_set as $key => $dir_name) {
			# code...
			if ($this->isFolder($dir_name)) {
				# code...
				$newPath = $p."\\".$dir_name;
				$this->autoload_libraries($newPath,$libraries);
			}
			foreach ($libraries_set as $key => $library) {
				# code...
				if($dir_name == $library) {
				# code...
				$path = $p."\\".$library;
				$path = str_replace("\\","/",$path);
				$this->paths[] = $path;
			}
			}
		}
	}
	function isFolder($name){
		if (strpos($name, '.') !== false) {
			return false;
		}else{
			return true;
		}
	}
}
  ?>