<?php

/**
 * 
 */


class Autoloader
{
	public $path;

	
	function __construct($library){
	# code...
		$root_path = __DIR__;
		$root_path = str_replace('\Helper','',$root_path);
		$directories_set = scandir($root_path);
		foreach ($directories_set as $key => $dir_name) {
			# code...
			if ($this->isFolder($dir_name)) {
				# code...
				$newPath = $root_path."\\".$dir_name;
				$this->autoload_libraries($newPath,$library);
			}
			if($dir_name == $library) {
				# code...
				$this->path = $root_path."\\".$library;
				$this->path = str_replace("\\","/",$this->path);
			}
		}	
	}

	public function autoload_libraries($p,$library)
	{
		# code...
		$directories_set = scandir($p);
		foreach ($directories_set as $key => $dir_name) {
			# code...
			if ($this->isFolder($dir_name)) {
				# code...
				$newPath = $p."\\".$dir_name;
				$this->autoload_libraries($newPath,$library);
			}
			if($dir_name == $library) {
				# code...
				$this->path = $p."\\".$library;
				$this->path = str_replace("\\","/",$this->path);
			}
		}
	}
	function isFolder($name){
		if (strpos($name, '.') !== false) {
			return false;
		}else{
			return true;
		}
	}
}
  ?>